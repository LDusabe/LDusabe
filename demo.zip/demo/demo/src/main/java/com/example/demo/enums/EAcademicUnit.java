package com.example.demo.enums;

public enum EAcademicUnit {
    PROGRAMME,
    FACULTY,
    DEPARTMENT;
}
