package com.example.demo.enums;

public enum ERegistrationStatus {
    PENDING,
    ADMITTED, REJECTED;
}
