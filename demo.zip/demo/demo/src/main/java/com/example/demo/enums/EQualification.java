package com.example.demo.enums;

public enum EQualification {
    MASTER,
    PHD,
    PROFESSOR;
}
